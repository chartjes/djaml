from loaders import haml_loaders as _loaders

locals().update(_loaders)
